NES ROM Hack by Emanuele Rodolà
https://github.com/erodola/bigram-nes
2025/08/07

This patch replaces the original Final Fantasy (NES) character naming screen with an AI-powered generator. It automatically creates fantasy-style names and assigns random classes for your party.

Just press B to shuffle, and A to confirm.

Apply the included IPS patch to a clean US FF1 ROM (MD5: d111fc7770e12f67474897aaad834c0c).

For source code, details, and training scripts:
https://github.com/erodola/bigram-nes