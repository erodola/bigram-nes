NES ROM Hack by Emanuele Rodolà
https://github.com/erodola/bigram-nes
2025/08/18

This patch replaces the original Dragon Warrior (NES) character naming screen with an AI-powered generator. It automatically creates fantasy-style names of 3-8 letters.

Just press B to regenerate a name, A to confirm.

Apply the included IPS patch to a clean DW ROM (US version) with matching checksums:

ROM CRC32: 3b3f88f0
ROM SHA-1: 73f9b88def80756ef29c5aa1a724c3112e5918c1

Dragon Warrior (U) (PRG0) [!].nes  (GoodNES)
Dragon Warrior (U) (PRG0).nes      (GoodNES)

File MD5: 1cfeeac7a20b405780eea318d3d1af2a

For source code, details, and training scripts:
https://github.com/erodola/bigram-nes